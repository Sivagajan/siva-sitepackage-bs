<?php
$EM_CONF[$_EXTKEY] = [
    'title' => 'Siva Sitepackage',
    'description' => 'Kickstarter Sitepackage to Create Websites based on Bootstrap',
    'category' => 'plugin',
    'author' => 'Sivagajan Karunanathan',
    'author_email' => 'sivagajan@gmail.com',
    'author_company' => 'sivtech',
    'state' => 'alpha',
    'version' => '0.0.1',
    'constraints' => [
        'depends' => [
            'typo3' => '12.4-13.0',
        ],
        'conflicts' => [
        ],
        'suggests' => [
        ],
    ],
];